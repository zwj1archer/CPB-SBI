load I;
load L;

TestFileName = dir('C:/Foreground_Detection/trainraw17/*.png');
test_t=32;

[w,h]=size(I);
MASK=zeros(w,h,'single');
imshow(I);
I2=medfilt2(I);%Median filter
figure
imshow(I2);

%Compute the number of foreground pixels from result by CPB
i=0;
for x=1:w
    for y=1:h
         
        if I2(x,y)==255
           
           i=i+1;
        end
        
    end
end

%Record the position of foreground pxiels
p1=zeros(1,i);
p2=zeros(1,i);
n=1;
for x=1:w
    for y=1:h
         
        if I2(x,y)==255
           p1(n)=x;
           p2(n)=y;
           n=n+1;
        end
        
    end
end

%Compute the value of superpixels resuls in these foreground pixels
p3=zeros(1,i);

for j=1:i
  
        
       p3(j)=L(p1(j),p2(j)); 
     
          
end

%Remove redundancy and take out non-repeating elements
p4=unique(p3);

[n1,m1]=size(p4);

%Mask the motion in background and save result
for j1=1:m1
  for x1=1:w
    for y1=1:h
        
       if L(x1,y1)==p4(j1)
           
           MASK(x1,y1)=255;
       end
        
        
        
    end
 end
end

   figure
   imshow(MASK);
   
   save MASK MASK

   s=strcat('./subpre/',TestFileName(test_t).name,'.bmp');
   imwrite(MASK,s);
