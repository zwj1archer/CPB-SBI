% the simple linear iterative clustering (SLIC) algorithm to do superpixel segmentation
A = imread('0032_color.png');%Read the raw input
figure
imshow(A);
%Calculate superpixels of the image.
[L,N] = superpixels(A,350);
%Display the superpixel boundaries overlaid on the original image.
figure
BW = boundarymask(L);
imshow(imoverlay(A,BW,'red'),'InitialMagnification',100)

I=imread('...\0032FD.bmp');%Read the result of Foreground Detection by CPB

save I I
save L L

