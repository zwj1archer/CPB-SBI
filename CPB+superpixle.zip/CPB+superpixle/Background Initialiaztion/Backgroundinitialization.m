load DBr;%the initial model computed by CPB
load DBg;%the initial model computed by CPB
load DBb;%the initial model computed by CPB (3 channels)
load MASK;

TestFileName = dir('C:/Foreground_Detection/trainraw17/*.png');
B=imread('...\0032_color.png');%Read the raw input
[w,h,Bands]=size(B);

tic
for x=1:w
    for y=1:h
        
        if MASK(x,y)==255
            
              
              B(x,y,1)=mean(DBr(x,y,:));
              B(x,y,2)=mean(DBg(x,y,:));
              B(x,y,3)=mean(DBb(x,y,:));
               
        end
        
    end
end
toc;
figure
imshow(B);


save B B%Background initialization result

test_t=32;
s=strcat('./subpre1/',TestFileName(test_t).name,'.bmp');
imwrite(B,s);